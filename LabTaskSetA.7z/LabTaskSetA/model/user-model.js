var db = require('./db');
module.exports = {

	validate : function(user,callback){
		var sql = "select * from user where username=? and password=?";
		db.getResults(sql,[user.username,user.password],function(results){ 
			if(results.length > 0 ){
				callback(true);
			}
			else{
				callback(false);
			}
		});
	},
	getByUname: function(username,callback){
		var sql = "select * from user where username=?";
		db.getResults(sql,[username],function(result){
			if(result.length>0){
				callback(result[0]);
			}
			else{
				callback(null);
			}
		});
	},
	getById: function(id, callback){
		var sql = "select * from user where id=?";
		db.getResult(sql, [id], function(result){
			if(result.length > 0){
				callback(result[0]);
			}else{
				callback(null);
			}
		});
	},
	getAll:function(callback){
		var sql = "select * from user";
		db.getResult(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback(null);
			}
		});
	},
	delete: function(id, callback){
		var sql = "delete from user where id=?";
		db.execute(sql, [id], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	update: function(user, callback){
		var sql = "update user set ename=?,connect=?, username=?, password=?  where id=?";
		db.execute(sql, [user.ename,user.connect,user.username, user.password, user.id], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	}

}