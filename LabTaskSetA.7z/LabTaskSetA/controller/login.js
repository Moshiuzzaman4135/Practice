var express = require('express');
var userModel = require.main.require('./model/user-model');
var router = express.Router();


router.get('/',function(req,res){
	consloe.log('login page requested');
	res.render('login/index');
});

router.post('/',function(req,res){
	
	var user = {
		username: req.body.username,
		password: req.body.password
	};
	userModel.validate(user,function(status){
		if(status)
		{
		
			res.cookie('username',req.body.username);
			res.redirect('/home');
		}
		else{
			res.redirect('/login');
		}
	});
});

module.exports = router;
